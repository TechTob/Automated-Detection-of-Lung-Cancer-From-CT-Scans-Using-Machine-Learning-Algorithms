// Handle form submission on the upload page
document.getElementById('upload-form')?.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    alert('CT scan uploaded successfully. Check the results page.');
});
