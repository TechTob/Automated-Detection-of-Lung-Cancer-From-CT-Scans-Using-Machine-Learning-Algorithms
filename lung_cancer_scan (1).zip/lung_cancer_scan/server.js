const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true }));

// Simulated database of results
let resultsDatabase = [];

// Define routes
app.get('/', (req, res) => {
    res.render('index');
});

app.get('/upload', (req, res) => {
    res.render('upload');
});

// Handle form submission for the upload page
app.post('/results', (req, res) => {
    const { patientName, patientAge, scanFile } = req.body;

    const newResult = {
        id: resultsDatabase.length + 1,
        patientName,
        patientAge,
        fileName: scanFile, // For simplicity, we'll just store the name here
        result: 'No signs of lung cancer detected.', // Placeholder result
    };

   

    resultsDatabase.push(newResult);
    res.redirect('/results');
});

app.get('/results', (req, res) => {
    res.render('results', { results: resultsDatabase });
});

app.get('/result/:id', (req, res) => {
    const resultId = parseInt(req.params.id);
    const result = resultsDatabase.find(record => record.id === resultId);
    if (result) {
        res.render('result', { result });
    } else {
        res.status(404).send('Result not found');
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
